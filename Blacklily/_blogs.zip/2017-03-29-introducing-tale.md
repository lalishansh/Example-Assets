---
layout: post
title:  "Introducing blacklily"
author: "Chester"
comments: true
tags: blacklily
excerpt_separator: <!--more-->
sticky: true
---

blacklily is a minimal [Jekyll](https://jekyllrb.com/) theme curated for storytellers. It is designed and developed by [myself](https://github.com/chesterhow/) for a friend who writes short stories.<!--more-->

## blacklily features
- Compatible with GitHub Pages
- Responsive design (looks just as good on mobile)
- Syntax highlighting, with the help of Pygments
- Markdown and HTML text formatting
- Pagination of posts
- Sticky posts
- Tags
- Excerpt management
- Disqus comments

Head over to the [Example Content]({{ site.baseurl }}/2017-03-16/example-content) post for a showcase of blacklily's text formatting features.

## Browser Support
blacklily works on most if not all modern browsers, including Chrome, Safari and Firefox 👍🏼

## Download or Contribute
blacklily is publicly hosted on GitHub, so go ahead and download or fork it at the [GitHub repository](https://github.com/chesterhow/blacklily). If you spot any bugs or have any suggestions, feel free to create an issue or make a pull request.

Thanks for checking out blacklily!
